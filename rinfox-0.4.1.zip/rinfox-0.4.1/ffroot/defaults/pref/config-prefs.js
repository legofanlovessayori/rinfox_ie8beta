pref("general.config.obscure_value", 0);
pref("general.config.filename", "config.js");
// Sandbox needs to be disabled in release and Beta versions
pref("general.config.sandbox_enabled", false);